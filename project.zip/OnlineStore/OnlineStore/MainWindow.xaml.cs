﻿
using OnlineStore.DB;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static OnlineStore.DB.DB;

namespace OnlineStore
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            var users = db.Users.ToList();

            if(users.Count() == 0)
            {
                var userTypes = new List<UserType>()
                {
                    new UserType("user"),
                    new UserType("manager"),
                    new UserType("administrator")
                };
                db.UserTypes.AddRange(userTypes);
                db.SaveChanges();

                var pinCode = new PinCode("1111");
                db.PinCodes.Add(pinCode);
                db.SaveChanges();

                var genders = new List<Gender>()
                {
                    new Gender("мужской"),
                    new Gender("женский")
                };
                db.Genders.AddRange(genders);
                db.SaveChanges();

                var user = new User("администратор", "12345678", "-", "-", null, db.Genders.Find(1), db.UserTypes.Find(3), null, db.PinCodes.Find(1));
                db.Users.Add(user);
                db.SaveChanges();

                var basket = new Basket(db.Users.Find(1));
                db.Baskets.Add(basket);
                db.SaveChanges();
            }

            Directory.CreateDirectory($@"{Directory.GetCurrentDirectory()}\Images\");

            frame.Navigate(new Login());
        }
    }
}