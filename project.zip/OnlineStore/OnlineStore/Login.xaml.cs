﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static OnlineStore.DB.DB;

namespace OnlineStore
{
    /// <summary>
    /// Логика взаимодействия для Login.xaml
    /// </summary>
    public partial class Login : Page
    {
        public Login()
        {
            InitializeComponent();
        }

        private void EnterButton_Click(object sender, RoutedEventArgs e)
        {
            var user = db.Users.Include(a => a.UserType).Include(a => a.Card).Include(a => a.Gender).Include(a => a.PinCode).Where(a => a.Name == login.Text).FirstOrDefault();
            if(user != null && user.Password == password.Password)
            {
                NavigationService.Navigate(new Store(user));
                return;
            }

            MessageBox.Show("Неверный логин или пароль");
        }

        private void RegistrationButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Registration());
        }
    }
}
