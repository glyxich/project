﻿using OnlineStore.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static OnlineStore.DB.DB;

namespace OnlineStore
{
    /// <summary>
    /// Логика взаимодействия для AddCategory.xaml
    /// </summary>
    public partial class AddCategory : Page
    {
        User user;
        public AddCategory(User _user)
        {
            InitializeComponent();
            user = _user;
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if(db.ProductCategories.Where(a => a.Name == name.Text).Count() > 0)
            {
                MessageBox.Show("Такая категория уже существует");
                return;
            }
            var category = new ProductCategory(name.Text);
            db.ProductCategories.Add(category);
            db.SaveChanges();

            NavigationService.Navigate(new Store(user));
        }
    }
}
