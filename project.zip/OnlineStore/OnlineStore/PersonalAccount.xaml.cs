﻿using Microsoft.VisualBasic.Logging;
using Microsoft.Win32;
using OnlineStore.DB;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static OnlineStore.DB.DB;

namespace OnlineStore
{
    /// <summary>
    /// Логика взаимодействия для PersonalAccount.xaml
    /// </summary>
    public partial class PersonalAccount : Page
    {
        string image = null;
        Card card = null;
        string oldLogin;
        public PersonalAccount(User user)
        {
            InitializeComponent();

            if(user.Image != null)
            {
                userImage.Source = new BitmapImage(new Uri(user.FullImagePath));
                image = user.Image;
            }
            login.Text = user.Name;
            password.Password = user.Password;
            passwordConfirm.Password = user.Password;
            email.Text = user.Email;
            phone.Text = user.Phone;
            card = user.Card;
            oldLogin = user.Name;

            gender.SelectedIndex = user.Gender.Id - 1;
        }

        private void Image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog()
            {
                Title = "Выбор изображения пользователя",
                Multiselect = false,
                Filter = "Изображение |*.png;*.jpg"
            };

            if ((bool)fileDialog.ShowDialog())
            {
                image = $@"{DateTime.Now.ToString("dd_MM_yyyy_HH_mm_ss")}_{Guid.NewGuid()}.png";

                string fullPath = @$"{Directory.GetCurrentDirectory()}\Images\{image}";

                using (FileStream openStream = new FileStream(fileDialog.FileName, FileMode.Open))
                {
                    using (FileStream saveStream = new FileStream(fullPath, FileMode.Create))
                    {
                        openStream.CopyTo(saveStream);
                    }
                }

                userImage.Source = new BitmapImage(new Uri(fullPath));
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (login.Text == "" || password.Password == "" || passwordConfirm.Password == "" || email.Text == "" || phone.Text == "")
            {
                MessageBox.Show("Все поля должны быть заполнены");
                return;
            }
            if (login.Text != oldLogin && db.Users.Where(a => a.Name == login.Text).Count() != 0)
            {
                MessageBox.Show("Пользователь с таким логином уже существует");
                return;
            }
            if (password.Password != passwordConfirm.Password)
            {
                MessageBox.Show("Пароли не совпадают");
                return;
            }

            if (card != null)
                card = db.Cards.Find(card.Id);

            var editetUser = new User(login.Text, password.Password, email.Text, phone.Text, image, db.Genders.Find(gender.SelectedIndex + 1), db.UserTypes.Find(1), card, null);
            db.Users.Remove(db.Users.Where(a => a.Name == oldLogin).First());
            db.Users.Add(editetUser);
            db.SaveChanges();
            NavigationService.GoBack();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
