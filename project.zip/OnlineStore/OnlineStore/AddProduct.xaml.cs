﻿using Microsoft.Win32;
using OnlineStore.DB;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static OnlineStore.DB.DB;

namespace OnlineStore
{
    /// <summary>
    /// Логика взаимодействия для AddProduct.xaml
    /// </summary>
    public partial class AddProduct : Page
    {
        User user;
        string image = null;
        public AddProduct(User _user)
        {
            InitializeComponent();

            category.ItemsSource = db.ProductCategories.ToList();
            category.DisplayMemberPath = "Name";

            user = _user;
        }

        private void Image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog()
            {
                Title = "Выбор изображения продукта",
                Multiselect = false,
                Filter = "Изображение |*.png;*.jpg"
            };

            if ((bool)fileDialog.ShowDialog())
            {
                image = $@"{DateTime.Now.ToString("dd_MM_yyyy_HH_mm_ss")}_{Guid.NewGuid()}.png";

                string fullPath = @$"{Directory.GetCurrentDirectory()}\Images\{image}";

                using (FileStream openStream = new FileStream(fileDialog.FileName, FileMode.Open))
                {
                    using (FileStream saveStream = new FileStream(fullPath, FileMode.Create))
                    {
                        openStream.CopyTo(saveStream);
                    }
                }

                productImage.Source = new BitmapImage(new Uri(fullPath));
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (name.Text == "" || price.Text == "" || weight.Text == "")
            {
                MessageBox.Show("Все поля должны быть заполнены");
                return;
            }
            if(category.SelectedItem == null)
            {
                MessageBox.Show("Продукт не может быть без категории");
                return;
            }
            if(db.Products.Where(a => a.Name == name.Text).Count() > 0)
            {
                MessageBox.Show("Продукт с таким названием уже существует");
                return;
            }

            var product = new Product(name.Text, Convert.ToDouble(price.Text), Convert.ToDouble(weight.Text), image, db.ProductCategories.Find(((ProductCategory)category.SelectedItem).Id));
            db.Products.Add(product);
            db.SaveChanges();

            NavigationService.Navigate(new Store(user));
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
