﻿using OnlineStore.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static OnlineStore.DB.DB;

namespace OnlineStore
{
    /// <summary>
    /// Логика взаимодействия для Pay.xaml
    /// </summary>
    public partial class Pay : Page
    {
        User user;
        Basket basket;
        public Pay(User _user)
        {
            InitializeComponent();
            user = _user;

            if(user.Card != null)
            {
                number.Text = user.Card.CardNumber;
            }

            basket = db.Baskets.Where(a => a.User.Id == user.Id && a.Paided == false).FirstOrDefault();

            payButton.Content = $"Оплатить {basket.ToltalPrice} руб.";
        }

        private void payButton_Click(object sender, RoutedEventArgs e)
        {
            if (number.Text == "" || mouth.Text == "" || day.Text == "" || cvc.Text == "" || address.Text == "" || entrance.Text == "" || stage.Text == "" || apartment.Text == "")
            {
                MessageBox.Show("Все поля должны быть заполнены");
                return;
            }

            if(user.Card != null)
            {
                db.Cards.Find(user.Card.Id).CardNumber = number.Text;
            }
            else
            {
                Card card = new Card(number.Text);
                db.Cards.Add(card);
                user.Card = card;
            }
            basket.Paided = true;

            Basket newBasket = new Basket(user);
            db.Baskets.Add(newBasket);

            Cheque cheque = new Cheque(basket, DateTime.Now);
            db.Cheques.Add(cheque);

            db.SaveChanges();

            NavigationService.Navigate(new Store(user));
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
