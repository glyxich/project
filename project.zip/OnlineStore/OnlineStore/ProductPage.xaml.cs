﻿using Microsoft.Win32;
using OnlineStore.DB;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static OnlineStore.DB.DB;

namespace OnlineStore
{
    /// <summary>
    /// Логика взаимодействия для ProductPage.xaml
    /// </summary>
    public partial class ProductPage : Page
    {
        Product product;
        User user;
        string image;
        public ProductPage(Product _product, User _user)
        {
            InitializeComponent();
            product = _product;
            user = _user;

            name.Text = product.Name;
            price.Text = product.Price.ToString();
            weight.Text = product.Weight.ToString();
            if(product.Image != null)
            {
                productImage.Source = new BitmapImage(new Uri(product.FullImagePath));
            }
            var categories = db.ProductCategories.ToList();
            category.ItemsSource = categories;
            category.DisplayMemberPath = "Name";
            category.SelectedIndex = categories.IndexOf(product.ProductCategory);
            image = product.Image;
        }

        private void Image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog()
            {
                Title = "Выбор изображения продукта",
                Multiselect = false,
                Filter = "Изображение |*.png;*.jpg"
            };

            if ((bool)fileDialog.ShowDialog())
            {
                image = $@"{DateTime.Now.ToString("dd_MM_yyyy_HH_mm_ss")}_{Guid.NewGuid()}.png";

                string fullPath = @$"{Directory.GetCurrentDirectory()}\Images\{image}";

                using (FileStream openStream = new FileStream(fileDialog.FileName, FileMode.Open))
                {
                    using (FileStream saveStream = new FileStream(fullPath, FileMode.Create))
                    {
                        openStream.CopyTo(saveStream);
                    }
                }

                productImage.Source = new BitmapImage(new Uri(fullPath));
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if(name.Text == "" || price.Text == "" || weight.Text == "")
            {
                MessageBox.Show("Все поля должны быть заполнены");
                return;
            }
            product.Name = name.Text;
            product.Price = Convert.ToDouble(price.Text);
            product.Weight = Convert.ToDouble(weight.Text);
            product.Image = image;
            product.ProductCategory = db.ProductCategories.Find(((ProductCategory)category.SelectedItem).Id);
            db.SaveChanges();

            NavigationService.Navigate(new Store(user));
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            db.Products.Remove(product);
            db.SaveChanges();

            NavigationService.Navigate(new Store(user));
        }   
        
        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
