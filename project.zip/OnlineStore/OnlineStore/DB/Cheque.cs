﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineStore.DB
{
    public class Cheque
    {
        [Key] public int Id { get; set; }
        [Required] public virtual Basket Basket { get; set; }
        [Required] public DateTime BuyDateTime { get; set; }

        public Cheque(Basket basket, DateTime buyDateTime)
        {
            Basket = basket;
            BuyDateTime = buyDateTime;
        }

        private Cheque() { }
    }
}
