﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineStore.DB
{
    public class BasketProduct
    {
        [Key] public int Id { get; set; }
        [Required] public Basket Basket { get; set; }
        [Required] public Product Product { get; set; }
        [Required] public int Count { get; set; }

        public BasketProduct(Basket basket, Product product, int count)
        {
            Basket = basket;
            Product = product;
            Count = count;
        }

        private BasketProduct() { }
    }
}
