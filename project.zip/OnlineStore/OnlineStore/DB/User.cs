﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineStore.DB
{
    public class User
    {
        [Key] public int Id { get; set; }
        [Required] public string Name { get; set; }
        [Required] public string Password { get; set; }
        [Required] public string Email { get; set; }
        [Required] public string Phone { get; set; }
        public string? Image { get; set; }
        [Required] public Gender Gender { get; set; }
        [Required] public UserType UserType { get; set; }
        public virtual Card? Card { get; set; }
        public virtual PinCode? PinCode { get; set; }

        public string FullImagePath
        {
            get { return $"{Directory.GetCurrentDirectory()}/Images/{Image}"; }
        }

        public User(string name, string password, string email, string phone, string? image, Gender gender, UserType userType, Card? card, PinCode? pinCode)
        {
            Name = name;
            Password = password;
            Email = email;
            Phone = phone;
            Image = image;
            Gender = gender;
            UserType = userType;
            Card = card;
            PinCode = pinCode;
        }

        private User() { }
    }
}
