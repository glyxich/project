﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineStore.DB
{
    public class Product
    {
        [Key] public int Id { get; set; }
        [Required] public string Name { get; set; }
        [Required] public double Price { get; set; }
        [Required] public double Weight { get; set; }
        public string? Image { get; set; }
        [Required] public virtual ProductCategory ProductCategory { get; set; }

        public string FullImagePath
        {
            get { return $"{Directory.GetCurrentDirectory()}/Images/{Image}"; }
        }

        public Product(string name, double price, double weight, string? image, ProductCategory productCategory)
        {
            Name = name;
            Price = price;
            Weight = weight;
            Image = image;
            ProductCategory = productCategory;
        }

        private Product() { }
    }
}
