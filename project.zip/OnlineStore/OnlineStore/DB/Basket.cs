﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineStore.DB
{
    public class Basket
    {
        [Key] public int Id { get; set; }
        [Required] public virtual User User { get; set; }
        [Required] public bool Paided { get; set; }
        public double ToltalPrice
        {
            get
            {
                var basketProducts = DB.db.BasketProducts.Include(a => a.Product).Where(a => a.Basket.Id == Id).ToList();
                double totalPrice = 0;
                foreach (var basketProduct in basketProducts)
                {
                    totalPrice += basketProduct.Product.Price * basketProduct.Count;
                }
                return totalPrice;
            }
        }

        public Basket(User user)
        {
            User = user;
            Paided = false;
        }

        private Basket() { }
    }
}
