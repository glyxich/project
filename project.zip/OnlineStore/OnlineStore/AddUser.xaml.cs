﻿using Microsoft.Win32;
using OnlineStore.DB;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static OnlineStore.DB.DB;

namespace OnlineStore
{
    /// <summary>
    /// Логика взаимодействия для AddUser.xaml
    /// </summary>
    public partial class AddUser : Page
    {
        User user;
        string image = null;
        public AddUser(User _user)
        {
            InitializeComponent();
            user = _user;
        }

        private void Image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog()
            {
                Title = "Выбор изображения пользователя",
                Multiselect = false,
                Filter = "Изображение |*.png;*.jpg"
            };

            if ((bool)fileDialog.ShowDialog())
            {
                image = $@"{DateTime.Now.ToString("dd_MM_yyyy_HH_mm_ss")}_{Guid.NewGuid()}.png";

                string fullPath = @$"{Directory.GetCurrentDirectory()}\Images\{image}";

                using (FileStream openStream = new FileStream(fileDialog.FileName, FileMode.Open))
                {
                    using (FileStream saveStream = new FileStream(fullPath, FileMode.Create))
                    {
                        openStream.CopyTo(saveStream);
                    }
                }

                userImage.Source = new BitmapImage(new Uri(fullPath));
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if(pinConfirm.Password != user.PinCode.Code)
            {
                MessageBox.Show("Пин код неверный");
                return;
            }
            if ((login.Text == "" || password.Password == "" || passwordConfirm.Password == "" || email.Text == "" || phone.Text == "") || (type.SelectedIndex == 2 && pin.Password == ""))
            {
                MessageBox.Show("Все поля должны быть заполнены");
                return;
            }
            if (db.Users.Where(a => a.Name == login.Text).Count() != 0)
            {
                MessageBox.Show("Пользователь с таким логином уже существует");
                return;
            }
            if (password.Password != passwordConfirm.Password)
            {
                MessageBox.Show("Пароли не совпадают");
                return;
            }

            PinCode pinCode = null;
            if(type.SelectedIndex == 2)
            {
                pinCode = new PinCode(pin.Password);
            }

            var newUser = new User(login.Text, password.Password, email.Text, phone.Text, image, db.Genders.Find(gender.SelectedIndex + 1), db.UserTypes.Find(type.SelectedIndex + 1), null, pinCode);
            Basket basket = new Basket(newUser);
            db.Baskets.Add(basket);
            db.SaveChanges();

            NavigationService.Navigate(new Store(user));
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
