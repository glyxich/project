﻿using Microsoft.EntityFrameworkCore;
using OnlineStore.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static OnlineStore.DB.DB;

namespace OnlineStore
{
    /// <summary>
    /// Логика взаимодействия для Store.xaml
    /// </summary>
    public partial class Store : Page
    {
        User user;
        string selectedCategory = "Все";
        double rowHeight = 210;
        public Store(User _user)
        {
            InitializeComponent();

            user = _user;

            var categories = db.ProductCategories.ToList();
            Button allButton = new Button();
            allButton.Content = "Все";
            allButton.Click += CategoryButton_Click;
            categoryList.Children.Add(allButton);
            foreach (var category in categories)
            {
                Button button = new Button();
                button.Content = category.Name;
                button.Click += CategoryButton_Click;
                categoryList.Children.Add(button);
            }

            if(user.UserType.Name == "administrator" || user.UserType.Name == "manager")
            {
                rowHeight = 230;
                AddCategoryButton.Visibility = Visibility.Visible;
                AddProductButton.Visibility = Visibility.Visible;
            }
            if(user.UserType.Name == "administrator")
            {
                AddUserButton.Visibility = Visibility.Visible;
            }

            SortProducts();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Login());
        }

        private void ProfileButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new PersonalAccount(user));
        }

        private void BasketButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new BasketPage(user));
        }

        private void CategoryButton_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            selectedCategory = (string)button.Content;
            SortProducts();
        }

        private void search_TextChanged(object sender, TextChangedEventArgs e)
        {
            SortProducts();
        }

        private void SortProducts()
        {
            var products = db.Products.Include(a => a.ProductCategory).ToList();

            if(search.Text != "")
            {
                products = products.Where(a => a.Name == search.Text).ToList();
            }
            if(selectedCategory != "Все")
            {
                products = products.Where(a => a.ProductCategory.Name == selectedCategory).ToList();
            }

            productsGrid.Children.Clear();
            productsGrid.RowDefinitions.Clear();
            for (int i = 0; i < products.Count(); i++)
            {
                if(i % 5 == 0)
                {
                    RowDefinition row = new RowDefinition();
                    row.Height = new GridLength(rowHeight);
                    productsGrid.RowDefinitions.Add(row);
                    
                }
                Border border = createProduct(products[i]);
                productsGrid.Children.Add(border);
                border.SetValue(Grid.ColumnProperty, i % 5);
                border.SetValue(Grid.RowProperty, i / 5);
            }
        }

        private void AddToBasketButton_Click(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;
            var parent = (Grid)button.Parent;
            var name = (Label)parent.Children[1];
            var product = db.Products.Where(a => a.Name == name.Content).FirstOrDefault();
            var basket = db.Baskets.Where(a => a.User.Id == user.Id && a.Paided == false).FirstOrDefault();
            var basketProduct = new BasketProduct(basket, product, 1);
            if(db.BasketProducts.Where(a => a.Basket.Id == basket.Id && a.Product.Id == product.Id).Count() > 0)
            {
                MessageBox.Show("Этот продукт уже есть в корзине");
                return;
            }
            db.BasketProducts.Add(basketProduct);
            db.SaveChanges();
        }

        private void EditProductButton_Click(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;
            var parent = (Grid)button.Parent;
            var name = (Label)parent.Children[1];
            var product = db.Products.Include(a => a.ProductCategory).Where(a => a.Name == name.Content).FirstOrDefault();
            NavigationService.Navigate(new ProductPage(product, user));
        }

        private Border createProduct(Product product)
        {
            Border border = new Border();
            border.Margin = new Thickness(5);
            border.BorderThickness = new Thickness(1);
            border.BorderBrush = Brushes.Black;

            Grid grid = new Grid();
            RowDefinition rowDefinition1 = new RowDefinition();
            rowDefinition1.Height = new GridLength(4, GridUnitType.Star);
            grid.RowDefinitions.Add(rowDefinition1);
            grid.RowDefinitions.Add(new RowDefinition());
            grid.RowDefinitions.Add(new RowDefinition());
            grid.RowDefinitions.Add(new RowDefinition());
            grid.RowDefinitions.Add(new RowDefinition());

            Image image = new Image();
            image.Height = 80;
            image.Width = 80;
            image.Stretch = Stretch.Fill;
            if(product.Image != null)
            {
                image.Source = new BitmapImage(new Uri(product.FullImagePath));
            }
            grid.Children.Add(image);

            Label name = new Label();
            name.Name = "name";
            name.FontWeight = FontWeights.Bold;
            name.Content = product.Name;
            grid.Children.Add(name);
            name.SetValue(Grid.RowProperty, 1);

            Label price = new Label();
            price.Content = $"{product.Price} руб.";
            grid.Children.Add(price);
            price.SetValue(Grid.RowProperty, 2);

            Label weight = new Label();
            weight.Content = $"{product.Weight} г.";
            grid.Children.Add(weight);
            weight.SetValue(Grid.RowProperty, 3);

            Button button = new Button();
            button.Content = "В корзину";
            button.Click += AddToBasketButton_Click;
            grid.Children.Add(button);
            button.SetValue(Grid.RowProperty, 4);

            if(user.UserType.Name == "administrator" || user.UserType.Name == "manager")
            {
                grid.RowDefinitions.Add(new RowDefinition());

                Button editButton = new Button();
                editButton.Content = "Изменить";
                editButton.Click += EditProductButton_Click;
                grid.Children.Add(editButton);
                editButton.SetValue(Grid.RowProperty, 5);
            }

            border.Child = grid;

            return border;
        }

        private void AddCategoryButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddCategory(user));
        }

        private void AddProductButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddProduct(user));
        }

        private void AddUserButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddUser(user));
        }
    }
}
