﻿using Microsoft.EntityFrameworkCore;
using OnlineStore.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static OnlineStore.DB.DB;

namespace OnlineStore
{
    /// <summary>
    /// Логика взаимодействия для BasketPage.xaml
    /// </summary>
    public partial class BasketPage : Page
    {
        User user;
        public BasketPage(User _user)
        {
            InitializeComponent();

            user = _user;
            UpdateProducts();
        }

        private void UpdateProducts()
        {
            var basket = db.Baskets.Where(a => a.User == user && a.Paided == false).FirstOrDefault();
            var basketProducts = db.BasketProducts.Include(a => a.Product).Where(a => a.Basket.Id == basket.Id).ToList();

            payButton.Content = $"Перейти к оплате {basket.ToltalPrice} руб.";

            productsGrid.Children.Clear();
            productsGrid.RowDefinitions.Clear();
            for (int i = 0; i < basketProducts.Count(); i++)
            {
                if (i % 5 == 0)
                {
                    RowDefinition row = new RowDefinition();
                    row.Height = new GridLength(210);
                    productsGrid.RowDefinitions.Add(row);

                }
                Border border = createProduct(basketProducts[i]);
                productsGrid.Children.Add(border);
                border.SetValue(Grid.ColumnProperty, i % 5);
                border.SetValue(Grid.RowProperty, i / 5);
            }
        }

        private Border createProduct(BasketProduct basketProducts)
        {
            Border border = new Border();
            border.Margin = new Thickness(5);
            border.BorderThickness = new Thickness(1);
            border.BorderBrush = Brushes.Black;

            Grid grid = new Grid();
            RowDefinition rowDefinition1 = new RowDefinition();
            rowDefinition1.Height = new GridLength(4, GridUnitType.Star);
            grid.RowDefinitions.Add(rowDefinition1);
            grid.RowDefinitions.Add(new RowDefinition());
            grid.RowDefinitions.Add(new RowDefinition());
            grid.RowDefinitions.Add(new RowDefinition());
            grid.RowDefinitions.Add(new RowDefinition());

            Image image = new Image();
            image.Height = 80;
            image.Width = 80;
            image.Stretch = Stretch.Fill;
            if (basketProducts.Product.Image != null)
            {
                image.Source = new BitmapImage(new Uri(basketProducts.Product.FullImagePath));
            }
            grid.Children.Add(image);

            Label name = new Label();
            name.Name = "name";
            name.FontWeight = FontWeights.Bold;
            name.Content = basketProducts.Product.Name;
            grid.Children.Add(name);
            name.SetValue(Grid.RowProperty, 1);

            Label price = new Label();
            price.Content = $"{basketProducts.Product.Price} руб.";
            grid.Children.Add(price);
            price.SetValue(Grid.RowProperty, 2);

            Label weight = new Label();
            weight.Content = $"{basketProducts.Product.Weight} г.";
            grid.Children.Add(weight);
            weight.SetValue(Grid.RowProperty, 3);

            Grid grid1 = new Grid();
            grid1.ColumnDefinitions.Add(new ColumnDefinition());
            grid1.ColumnDefinitions.Add(new ColumnDefinition());
            grid1.ColumnDefinitions.Add(new ColumnDefinition());

            Button plus = new Button();
            plus.Content = "+";
            plus.Height = 25;
            plus.Width = 25;
            plus.Click += countButton_Click;
            grid1.Children.Add(plus);

            Label count = new Label();
            count.Name = "count";
            count.Content = basketProducts.Count;
            count.HorizontalAlignment = HorizontalAlignment.Center;
            grid1.Children.Add(count);
            count.SetValue(Grid.ColumnProperty, 1);

            Button minus = new Button();
            minus.Content = "-";
            minus.Height = 25;
            minus.Width = 25;
            minus.Click += countButton_Click;
            grid1.Children.Add(minus);
            minus.SetValue(Grid.ColumnProperty, 2);

            grid.Children.Add(grid1);
            grid1.SetValue(Grid.RowProperty, 4);

            border.Child = grid;

            return border;
        }

        private void countButton_Click(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;
            var parent = (Grid)((Grid)button.Parent).Parent;
            var name = (Label)parent.Children[1];
            var product = db.Products.Where(a => a.Name == name.Content).FirstOrDefault();
            var basket = db.Baskets.Where(a => a.User.Id == user.Id && a.Paided == false).FirstOrDefault();
            var basketProduct = db.BasketProducts.Where(a => a.Product.Id == product.Id && a.Basket.Id == basket.Id).FirstOrDefault();
            if(((Button)sender).Content == "+")
            {
                basketProduct.Count++;
            }
            else
            {
                basketProduct.Count--;
                if(basketProduct.Count == 0)
                {
                    db.BasketProducts.Remove(basketProduct);
                }
            }
            db.SaveChanges();

            UpdateProducts();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Store(user));
        }

        private void PayButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Pay(user));
        }
    }
}
